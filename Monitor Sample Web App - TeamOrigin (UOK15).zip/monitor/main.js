var uName, uId, uMobile, uEmail;

$(document).ready(function () {
  $.get("http://localhost:9000/api/user/", function (data, status) {

    $('#uname').html(data.userName);
    uName = data.userName;
    uId = data.userID;
    uMobile = data.userMobile;
    uEmail = data.userEmail;

    // M.toast({html: 'Sending message to ' + data.userMobile})
  });
});

package com.kln.teamorigin.sa.alert.api;

public class Threshold {

    private String thresholdValue;

    public Threshold() {
    }

    public Threshold(String thresholdValue)
    {
        this.thresholdValue = thresholdValue;
    }

    public String getValue() {
        return thresholdValue;
    }

    public void setValue(String thresholdValue) {
        this.thresholdValue = thresholdValue;
    }
}

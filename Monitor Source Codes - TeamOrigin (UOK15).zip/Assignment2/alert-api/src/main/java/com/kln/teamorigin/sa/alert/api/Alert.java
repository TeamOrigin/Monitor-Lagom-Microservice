package com.kln.teamorigin.sa.alert.api;

public class Alert {

    private String alertId, sensorID, sensorVal, timestamp;
    public static int count = 0;

    public Alert() {
    }

    public Alert(String sensorID,String timestamp, String sensorVal ) {
        this.alertId = String.valueOf(++count);
        this.sensorID = sensorID;
        this.sensorVal = sensorVal;
        this.timestamp = timestamp;
    }

    public String getAlertId() {
        return alertId;
    }

    public void setAlertId(String alertId) {
        this.alertId = alertId;
    }

    public String getSensorID() {
        return sensorID;
    }

    public void setSensorID(String sensorID) {
        this.sensorID = sensorID;
    }

    public String getSensorVal() {
        return sensorVal;
    }

    public void setSensorVal(String sensorVal) {
        this.sensorVal = sensorVal;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
}

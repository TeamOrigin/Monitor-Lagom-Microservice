package com.kln.teamorigin.sa.alert.api;

import static com.lightbend.lagom.javadsl.api.Service.named;
import static com.lightbend.lagom.javadsl.api.Service.pathCall;

import akka.Done;
import akka.NotUsed;
import com.kln.teamorigin.sa.user.api.CORSHeaderFilter;
import com.lightbend.lagom.javadsl.api.Descriptor;
import com.lightbend.lagom.javadsl.api.Service;
import com.lightbend.lagom.javadsl.api.ServiceCall;


public interface AlertService extends Service {

    ServiceCall<Alert, Done> addAlert();

    ServiceCall<NotUsed, Alert> getAlert(String a);

    ServiceCall<Threshold, Done> setThreshold();

    @Override
    default Descriptor descriptor() {
        // @formatter:off
        return named("alert").withCalls(
                pathCall("/api/alert", this::addAlert),
                pathCall("/api/alert/:id", this::getAlert),
                pathCall("/api/alert/setThreshold", this::setThreshold)
        ).withAutoAcl(true).withHeaderFilter(new CORSHeaderFilter());
        // @formatter:on
    }


}

package com.kln.teamorigin.sa.alert.impl;

import com.google.inject.AbstractModule;
import com.kln.teamorigin.sa.notification.api.NotificationService;
import com.lightbend.lagom.javadsl.server.ServiceGuiceSupport;
import com.kln.teamorigin.sa.alert.api.AlertService;

public class AlertModule extends AbstractModule implements ServiceGuiceSupport {
    @Override
    protected void configure() {
        bindService(AlertService.class, AlertServiceImpl.class);
        bindClient(NotificationService.class);
    }
}

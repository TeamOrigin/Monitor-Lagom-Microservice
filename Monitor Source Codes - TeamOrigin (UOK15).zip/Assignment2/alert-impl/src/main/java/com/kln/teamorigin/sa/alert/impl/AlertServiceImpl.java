package com.kln.teamorigin.sa.alert.impl;

import akka.Done;
import akka.NotUsed;
import com.kln.teamorigin.sa.alert.api.Alert;
import com.kln.teamorigin.sa.alert.api.Threshold;
import com.kln.teamorigin.sa.notification.api.Notification;
import com.kln.teamorigin.sa.notification.api.NotificationService;
import com.lightbend.lagom.javadsl.api.ServiceCall;

import javax.inject.Inject;

import com.kln.teamorigin.sa.alert.api.AlertService;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class AlertServiceImpl implements AlertService {
    private double threshold = 45.0;
    private AlertRepo alertRepo;
    private NotificationService notificationService;

    @Inject
    public AlertServiceImpl(AlertRepo alertRepo, NotificationService notificationService) {
        this.notificationService = notificationService;
        this.alertRepo = alertRepo;
    }

    @Override
    public ServiceCall<Alert, Done> addAlert() {
        return request -> {
            alertRepo.addAlert(request);
            double senVal = Double.parseDouble(
                    request.getSensorVal().replaceAll("\\D+",""));
            if (senVal > threshold) {
                try {
                    notificationService.notifyUser().invoke().toCompletableFuture().get();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }
            }
            return CompletableFuture.completedFuture(Done.getInstance());
        };
    }

    @Override
    public ServiceCall<NotUsed, Alert> getAlert(String a) {
        return request -> CompletableFuture
                .completedFuture(alertRepo.getAlert(a));
    }

    @Override
    public ServiceCall<Threshold, Done> setThreshold() {
        return request -> {

            threshold = Double.parseDouble(request.getValue().replaceAll("\\D+",""));

            System.out.println("\n\n\n\n\n\n ====================================================== \n\n");

            System.out.println(" New Threshold Value : "  + threshold);

            System.out.println("\n\n ====================================================== \n\n\n\n\n\n");

            return CompletableFuture.completedFuture(Done.getInstance());
        };
    }

}

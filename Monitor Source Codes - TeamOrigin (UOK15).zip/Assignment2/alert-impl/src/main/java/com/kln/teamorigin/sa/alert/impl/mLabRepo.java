package com.kln.teamorigin.sa.alert.impl;

import com.kln.teamorigin.sa.alert.api.Alert;

public class mLabRepo implements AlertRepo {


    @Override
    public Alert getAlert(String id) {
        /*
            Sending alert id to
        */
        return null;
    }

    @Override
    public void addAlert(Alert a) {

    }


}

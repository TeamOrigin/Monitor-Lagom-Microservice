package com.kln.teamorigin.sa.alert.impl;

import com.kln.teamorigin.sa.alert.api.Alert;

import java.util.HashMap;
import java.util.Map;

public class InMemoryAlertRepo implements AlertRepo {

    private Map<String, Alert> alertMap = new HashMap<>();

    public InMemoryAlertRepo() {
    }

    @Override
    public Alert getAlert(String id) {
        if (alertMap.containsKey(id)) {
            return alertMap.get(id);
        }
        return null;
    }

    @Override
    public void addAlert(Alert a) {
        a.setAlertId(String.valueOf(++Alert.count));
        alertMap.put(String.valueOf(Alert.count), a);
    }

}

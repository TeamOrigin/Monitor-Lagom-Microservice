package com.kln.teamorigin.sa.alert.impl;

import com.google.inject.ImplementedBy;
import com.kln.teamorigin.sa.alert.api.Alert;

@ImplementedBy(InMemoryAlertRepo.class)
public interface AlertRepo {
    Alert getAlert(String id);
    void addAlert(Alert a);
}

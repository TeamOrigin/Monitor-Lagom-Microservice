package com.kln.teamorigin.sa.notification.impl;

import akka.Done;
import akka.NotUsed;
import com.kln.teamorigin.sa.notification.api.Notification;
import com.kln.teamorigin.sa.notification.api.NotificationService;
import com.kln.teamorigin.sa.user.api.User;
import com.kln.teamorigin.sa.user.api.UserService;
import com.lightbend.lagom.javadsl.api.ServiceCall;

import javax.inject.Inject;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class NotificationServiceImpl implements NotificationService {

    UserService userService;

    @Inject
    public NotificationServiceImpl(UserService userService) {
        this.userService = userService;
    }

    @Override
    public ServiceCall<NotUsed, Done> notifyUser() {

        return request -> {
            try {
                Notification current = userService.getSelectedUser().invoke().toCompletableFuture().get().getUserChannel();

                System.out.println("\n\n\n\n\n\n ====================================================== \n\n");

                if (current.getChannelCall())
                    System.out.println("  Sending Notification - Call");
                if (current.getChannelEmail())
                    System.out.println("  Sending Notification - Email");
                if (current.getChannelSMS())
                    System.out.println("  Sending Notification - SMS");

                System.out.println("\n\n ====================================================== \n\n\n\n\n\n");

            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }

            return CompletableFuture.completedFuture(Done.getInstance());

        };
    }

    @Override
    public ServiceCall<Notification, Done> setChannel() {
        return request -> {
//            Notification.notification = request;
            System.out.println(" -------------------- Setted         ------------------------------");
            return CompletableFuture.completedFuture(Done.getInstance());
        };
    }
}

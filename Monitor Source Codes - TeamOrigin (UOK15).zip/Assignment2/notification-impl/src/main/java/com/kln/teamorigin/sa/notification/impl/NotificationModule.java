package com.kln.teamorigin.sa.notification.impl;

import com.google.inject.AbstractModule;
import com.kln.teamorigin.sa.notification.api.NotificationService;
import com.kln.teamorigin.sa.user.api.UserService;
import com.lightbend.lagom.javadsl.server.ServiceGuiceSupport;

public class NotificationModule extends AbstractModule implements ServiceGuiceSupport {
    @Override
    protected void configure() {
        bindService(NotificationService.class, NotificationServiceImpl.class);
        bindClient(UserService.class);
    }
}

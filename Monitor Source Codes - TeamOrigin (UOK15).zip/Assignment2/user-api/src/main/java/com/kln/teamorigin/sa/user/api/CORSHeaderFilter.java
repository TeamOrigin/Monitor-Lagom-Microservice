package com.kln.teamorigin.sa.user.api;

import com.lightbend.lagom.javadsl.api.transport.HeaderFilter;
import com.lightbend.lagom.javadsl.api.transport.Method;
import com.lightbend.lagom.javadsl.api.transport.RequestHeader;
import com.lightbend.lagom.javadsl.api.transport.ResponseHeader;

public class CORSHeaderFilter implements HeaderFilter {

    @Override
    public RequestHeader transformClientRequest(RequestHeader request) {
        return request;
    }

    @Override
    public RequestHeader transformServerRequest(RequestHeader request) {
        return request;
    }

    @Override
    public ResponseHeader transformServerResponse(ResponseHeader response, RequestHeader request) {
        ResponseHeader modifiedResponse = response.withHeader("Access-Control-Allow-Origin", "*");
        if (Method.OPTIONS.equals(request.method())) {
            modifiedResponse = modifiedResponse.withStatus(204).withHeader("Access-Control-Allow-Headers",
                    "Authorization,DNT,X-CustomHeader,Keep-Alive,User-Agent,X-Requested-With" +
                            ",If-Modified-Since,Cache-Control,Content-Type,Content-Range,Range").
                    withHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PATCH").
                    withHeader("Access-Control-Max-Age", "1728000");
        }
        return modifiedResponse;
    }

    @Override
    public ResponseHeader transformClientResponse(ResponseHeader response, RequestHeader request) {
        ResponseHeader modifiedResponse = response.withHeader("Access-Control-Allow-Origin", "*");
        if (Method.OPTIONS.equals(request.method())) {
            modifiedResponse = modifiedResponse.withStatus(204).withHeader("Access-Control-Allow-Headers",
                    "Authorization,DNT,X-CustomHeader,Keep-Alive,User-Agent,X-Requested-With" +
                            ",If-Modified-Since,Cache-Control,Content-Type,Content-Range,Range").
                    withHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PATCH").
                    withHeader("Access-Control-Max-Age", "1728000");
        }
        return modifiedResponse;
    }
}
package com.kln.teamorigin.sa.user.api;

import com.kln.teamorigin.sa.notification.api.Notification;

public class User {

    private String userID, userName, userMobile, userEmail;
    public static int userCount = 0;
    private Notification userChannel;

    public User() {
    }

    public User(String userName, String userMobile, String userEmail,Boolean SMS, Boolean Call, Boolean Email) {
        this.userID = String.valueOf(++userCount);
        this.userName = userName;
        this.userMobile = userMobile;
        this.userEmail = userEmail;
        this.userChannel = new Notification();
        this.userChannel.setChannelSMS(SMS);
        this.userChannel.setChannelEmail(Email);
        this.userChannel.setChannelCall(Call);
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserMobile() {
        return userMobile;
    }

    public void setUserMobile(String userMobile) {
        this.userMobile = userMobile;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public Notification getUserChannel() {
        return userChannel;
    }

    public void setUserChannel(Notification userChannel) {
        this.userChannel = userChannel;
    }
}

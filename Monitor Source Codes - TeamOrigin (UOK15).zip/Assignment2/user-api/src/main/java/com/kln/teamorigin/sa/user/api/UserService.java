package com.kln.teamorigin.sa.user.api;

import static com.lightbend.lagom.javadsl.api.Service.named;
import static com.lightbend.lagom.javadsl.api.Service.pathCall;

import akka.Done;
import akka.NotUsed;
import com.lightbend.lagom.javadsl.api.Descriptor;
import com.lightbend.lagom.javadsl.api.Service;
import com.lightbend.lagom.javadsl.api.ServiceCall;

public interface UserService extends Service {

    public ServiceCall<NotUsed, User> getUserById(String id);
    public ServiceCall<NotUsed, Done> selectUser(String id);
    public ServiceCall<NotUsed, User> getSelectedUser();

    public ServiceCall<User, Done> addUser();
    public ServiceCall<User, Done> updateUser();
    public ServiceCall<NotUsed, Done> removeUser(String id);

    @Override
    default Descriptor descriptor() {
        // @formatter:off
        return named("user").withCalls(
                pathCall("/api/user/:id", this::getUserById),
                pathCall("/api/user/select/:id", this::selectUser),
                pathCall("/api/user/", this::getSelectedUser),

                pathCall("/api/user/save", this::addUser),
                pathCall("/api/user/delete/:id", this::removeUser),
                pathCall("/api/user/update", this::updateUser)


        ).withAutoAcl(true).withHeaderFilter(new CORSHeaderFilter());
        // @formatter:on
    }


}

package com.kln.teamorigin.sa.user.impl;

import com.kln.teamorigin.sa.user.api.User;

import java.util.HashMap;
import java.util.Map;

public class InMemoryUserRepository implements UserRepository {

    private Map<String, User> userMap = new HashMap<>();
    public static User selectedUser;

    public InMemoryUserRepository() {
        User user1 = new User("Guest", "0710000000", "guest@user.com", true, true, true);
        userMap.put(String.valueOf(User.userCount), user1);
        selectedUser = user1;
    }

    @Override
    public User getUserById(String id) {
        if (userMap.containsKey(id)) {
            return userMap.get(id);
        }
        return null;
    }

    @Override
    public User getSelectedUser() {
        return selectedUser;
    }

    @Override
    public void selectUser(String id) {
        selectedUser = userMap.get(id);
    }

    @Override
    public void addUser(User user) {
        String userID = String.valueOf(++User.userCount);
        user.setUserID(userID);
        userMap.put(userID, user);
    }

    @Override
    public void updateUser(User user) {
        userMap.put(user.getUserID(),user);
    }

    @Override
    public void removeUser(String id) {
        userMap.remove(id);
    }

}

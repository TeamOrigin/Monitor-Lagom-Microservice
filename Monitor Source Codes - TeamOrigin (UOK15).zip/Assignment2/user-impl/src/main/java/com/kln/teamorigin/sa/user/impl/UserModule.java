package com.kln.teamorigin.sa.user.impl;

import com.google.inject.AbstractModule;
import com.kln.teamorigin.sa.notification.api.NotificationService;
import com.kln.teamorigin.sa.user.api.UserService;
import com.lightbend.lagom.javadsl.server.ServiceGuiceSupport;

public class UserModule extends AbstractModule implements ServiceGuiceSupport {
    @Override
    protected void configure() {
        bindService(UserService.class, UserServiceImpl.class);
        bindClient(NotificationService.class);
    }
}

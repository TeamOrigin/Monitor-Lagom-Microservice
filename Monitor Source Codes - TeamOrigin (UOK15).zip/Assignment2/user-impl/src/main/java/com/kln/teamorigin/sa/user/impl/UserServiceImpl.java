package com.kln.teamorigin.sa.user.impl;

import akka.Done;
import akka.NotUsed;
import com.kln.teamorigin.sa.user.api.User;
import com.kln.teamorigin.sa.user.api.UserService;
import com.lightbend.lagom.javadsl.api.ServiceCall;

import javax.inject.Inject;
import java.util.concurrent.CompletableFuture;

public class UserServiceImpl implements UserService {

    private UserRepository userRepository;

    @Inject
    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public ServiceCall<NotUsed, Done> selectUser(String id) {
        return request ->{
            userRepository.selectUser(id);
            return CompletableFuture.completedFuture(Done.getInstance());
        };
    }

    @Override
    public ServiceCall<NotUsed, User> getSelectedUser() {
        return request -> CompletableFuture
                .completedFuture(userRepository.getSelectedUser());
    }

    @Override
    public ServiceCall<NotUsed, User> getUserById(String id) {
        return request -> CompletableFuture
                .completedFuture(userRepository.getUserById(id));
    }

    @Override
    public ServiceCall<User, Done> addUser() {
        return request -> {
            userRepository.addUser(request);
            return CompletableFuture.completedFuture(Done.getInstance());
        };
    }

    @Override
    public ServiceCall<User, Done> updateUser() {
        return request -> {
            userRepository.updateUser(request);
            return CompletableFuture.completedFuture(Done.getInstance());
        };
    }

    @Override
    public ServiceCall<NotUsed, Done> removeUser(String id) {
        return request -> {
            userRepository.removeUser(id);
            return CompletableFuture.completedFuture(Done.getInstance());
        };
    }

}

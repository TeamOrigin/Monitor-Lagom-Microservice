package com.kln.teamorigin.sa.user.impl;

import com.google.inject.ImplementedBy;
import com.kln.teamorigin.sa.user.api.User;

@ImplementedBy(InMemoryUserRepository.class)
public interface UserRepository {
    User getUserById(String id);

    User getSelectedUser();

    void selectUser(String id);

    void addUser(User user);

    void updateUser(User user);

    void removeUser(String id);

}

package com.kln.teamorigin.sa.notification.api;

public class Notification {

    private Boolean channelSMS;
    private Boolean channelCall;
    private Boolean channelEmail;

//    public static Notification notification;

    public Notification() {
    }

    public Notification(Boolean channelSMS, Boolean channelCall, Boolean channelEmail) {
        this.channelSMS = channelSMS;
        this.channelCall = channelCall;
        this.channelEmail = channelEmail;
    }

    public Boolean getChannelSMS() { return channelSMS;
    }

    public void setChannelSMS(Boolean channelSMS) {
        this.channelSMS = channelSMS;
    }

    public Boolean getChannelCall() {
        return channelCall;
    }

    public void setChannelCall(Boolean channelCall) {
        this.channelCall = channelCall;
    }

    public Boolean getChannelEmail() {
        return channelEmail;
    }

    public void setChannelEmail(Boolean channelEmail) {
        this.channelEmail = channelEmail;
    }

}

package com.kln.teamorigin.sa.notification.api;

import static com.lightbend.lagom.javadsl.api.Service.named;
import static com.lightbend.lagom.javadsl.api.Service.pathCall;

import akka.Done;
import akka.NotUsed;
import com.lightbend.lagom.javadsl.api.Descriptor;
import com.lightbend.lagom.javadsl.api.Service;
import com.lightbend.lagom.javadsl.api.ServiceCall;

public interface NotificationService extends Service {

    ServiceCall<NotUsed, Done> notifyUser();
    ServiceCall<Notification,Done> setChannel();

    @Override
    default Descriptor descriptor() {
        // @formatter:off
        return named("notify").withCalls(
                pathCall("/api/notify", this::notifyUser)
        ).withAutoAcl(true);
        // @formatter:on
    }
}
